from django.contrib import admin
from django.urls import path
from reminders.views import save_reminder
from django.http import JsonResponse

urlpatterns = [
    path('admin/', admin.site.urls),
    path('reminder/', save_reminder),
    path('', lambda request: JsonResponse({"message": "Welcome to Remind Me Later API"})),
]
