from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import Reminder

@csrf_exempt
def save_reminder(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        reminder = Reminder.objects.create(
            date=data['date'],
            time=data['time'],
            message=data['message'],
            method=data['method']
        )
        return JsonResponse({'message': 'Reminder saved!', 'id': reminder.id})
    return JsonResponse({'error': 'Only POST method allowed'}, status=405)
